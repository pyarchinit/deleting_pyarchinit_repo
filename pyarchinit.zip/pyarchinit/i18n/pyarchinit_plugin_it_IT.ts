<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>DialogImageViewer</name>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="76"/>
        <source>Apri Immagini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="109"/>
        <source>Carica le immagini nel DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="135"/>
        <source>Tags manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="142"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="149"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="164"/>
        <source>Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="169"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="174"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_image_viewer_dialog.ui" line="182"/>
        <source>Assegna i tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogInfo</name>
    <message>
        <location filename="modules/gui/info.ui" line="14"/>
        <source>pyArchInit - Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/info.ui" line="26"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/images/banner.png&quot; /&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;pyArchinit  Version 0.4 - january 2010&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Archeological GIS Tools - PyArchInit it&apos;s tool to manage archaeological dataset with an high portability on the main platform&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Developpers:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Luca Mandolesi&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;adArte snc - Rimini - www.adartesnc.com&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Special thanks for testing to:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Giovanni Manghi&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Jerzy Sikora&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Michele Zappitelli&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;and supporting to:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Stefano Costa&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Francesco de Virgilio&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Giuseppe Naponiello&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Help:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;http://groups.google.it/group/pyarchinit-users&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;or email me:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;pyarchinit@gmail.com&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Site:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;pyarchinit.altervista.org&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogInventarioMateriali</name>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="20"/>
        <source>pyArchInit Gestione Scavi - Inventario materiali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="44"/>
        <source>DBMS Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="51"/>
        <source>Reload DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="60"/>
        <source>First rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="74"/>
        <source>Prev rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="88"/>
        <source>Next rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="102"/>
        <source>Last rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="121"/>
        <source>New record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="140"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="162"/>
        <source>Delete record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="194"/>
        <source>new search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="213"/>
        <source>search !!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="232"/>
        <source>Order by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="251"/>
        <source>View alls records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="300"/>
        <source>DB Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="316"/>
        <source>Ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="409"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="430"/>
        <source>record n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="506"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="475"/>
        <source>record tot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="676"/>
        <source>Inserisci un valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="579"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="591"/>
        <source>Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="616"/>
        <source>N° Inventairio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="628"/>
        <source>Definizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="640"/>
        <source>Criterio schedatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="681"/>
        <source>Malacofauna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="686"/>
        <source>Reperto cartaceo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="691"/>
        <source>Reperto ceramico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="696"/>
        <source>Reperto ligneo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="701"/>
        <source>Reperto metallico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="706"/>
        <source>Reperto osseo lavorato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="711"/>
        <source>Reperto osteologico animale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="716"/>
        <source>Reperto osteologico umano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="721"/>
        <source>Reperto vitreo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="758"/>
        <source>Acroma grezza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="763"/>
        <source>Acroma depurata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="768"/>
        <source>Maiolica arcaica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="773"/>
        <source>Vernice nera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="778"/>
        <source>Terra sigillata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="791"/>
        <source>Tipo reperto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="827"/>
        <source>Bicchiere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="832"/>
        <source>Boccale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="837"/>
        <source>Brocca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="842"/>
        <source>Olla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="847"/>
        <source>Piatto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="868"/>
        <source>Dati descrittivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="879"/>
        <source>Descrizione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="906"/>
        <source>Insufficiente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="911"/>
        <source>Scarso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="916"/>
        <source>Buono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="921"/>
        <source>Discreto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="926"/>
        <source>Ottimo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="939"/>
        <source>Stato di conservazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="965"/>
        <source>Datazione reperto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="992"/>
        <source>Dati quantitativi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1000"/>
        <source>Elementi reperto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1287"/>
        <source>inserisci riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1299"/>
        <source>rimuovi riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1060"/>
        <source>Elemento rinvenuto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1147"/>
        <source>Unita&apos; di misura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1152"/>
        <source>Quantita&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1082"/>
        <source>Misurazioni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1142"/>
        <source>Tipo di misura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1171"/>
        <source>Tecnologie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1236"/>
        <source>Tipo tecnologia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1241"/>
        <source>Posizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1246"/>
        <source>Tipo quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1251"/>
        <source>Unità di misura</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1256"/>
        <source>Qtà</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1267"/>
        <source>Rif Biblio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1275"/>
        <source>Rif. Bibliografici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1340"/>
        <source>Autore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1345"/>
        <source>Anno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1350"/>
        <source>Titolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1355"/>
        <source>Pag.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1360"/>
        <source>Fig.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1371"/>
        <source>Riferimenti stratigrafici e magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1389"/>
        <source>Dati stratigrafici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1437"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1478"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1510"/>
        <source>Dati magazzino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1539"/>
        <source>Nr. Cassa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1571"/>
        <source>Lavato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1587"/>
        <source>Luogo di conservazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1624"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_inventario_reperti_ui.ui" line="1639"/>
        <source>Exp schede Pdf </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogPeriodoFase</name>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="20"/>
        <source>pyArchInit Gestione Scavi - Periodizzazione di scavo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="44"/>
        <source>DBMS Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="51"/>
        <source>Reload DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="60"/>
        <source>First rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="74"/>
        <source>Prev rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="88"/>
        <source>Next rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="102"/>
        <source>Last rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="121"/>
        <source>New record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="140"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="162"/>
        <source>Delete record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="194"/>
        <source>new search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="213"/>
        <source>search !!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="232"/>
        <source>Order by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="251"/>
        <source>View alls records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="300"/>
        <source>DB Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="316"/>
        <source>Ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="427"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="448"/>
        <source>record n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="706"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="493"/>
        <source>record tot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="581"/>
        <source>Inserisci un valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="594"/>
        <source>Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="711"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="716"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="721"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="726"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="731"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="736"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="741"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="746"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="751"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="756"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="766"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="776"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="761"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="771"/>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="789"/>
        <source>Fase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="801"/>
        <source>Periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="818"/>
        <source>Codice periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="890"/>
        <source>Descrizione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="916"/>
        <source>Cronologia </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="973"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="940"/>
        <source>Iniziale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="952"/>
        <source>Finale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="1012"/>
        <source>Dati descrittivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Periodo_fase_ui.ui" line="1040"/>
        <source>Estesa letterale </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSite</name>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="20"/>
        <source>pyArchInit Gestione Scavi - Scheda Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="42"/>
        <source>DBMS Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="49"/>
        <source>Reload DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="58"/>
        <source>Next rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="72"/>
        <source>Last rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="91"/>
        <source>New record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="110"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="145"/>
        <source>new search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="164"/>
        <source>search !!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="183"/>
        <source>Order by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="202"/>
        <source>View alls records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="229"/>
        <source>Prev rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="243"/>
        <source>First rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="265"/>
        <source>Delete record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="301"/>
        <source>DB Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="317"/>
        <source>Ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="410"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="431"/>
        <source>record n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="507"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="476"/>
        <source>record tot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="558"/>
        <source>Inserisci un valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="566"/>
        <source>Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="585"/>
        <source>Dati descrittivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="613"/>
        <source>Descrizione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="635"/>
        <source>Italia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="648"/>
        <source>Nazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="688"/>
        <source>Comune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="714"/>
        <source>Provincia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Site_ui.ui" line="726"/>
        <source>Regione</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogSostituisciValori</name>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="22"/>
        <source>Sostituisci i valori nel campo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="75"/>
        <source>nome del campo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="40"/>
        <source>con il valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="47"/>
        <source>inserisci un valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="56"/>
        <source>Sostituisci</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="68"/>
        <source>In base ai valori selezionati sul GIS nel campo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="86"/>
        <source>Sostituisci i valori nella tabella</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_UpdValues.ui" line="93"/>
        <source>nome del layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogStruttura</name>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="20"/>
        <source>pyArchInit Gestione Scavi - Scheda Struttura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="60"/>
        <source>DBMS Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="67"/>
        <source>Reload DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="76"/>
        <source>First rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="90"/>
        <source>Prev rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="104"/>
        <source>Next rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="118"/>
        <source>Last rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="137"/>
        <source>New record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="156"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="178"/>
        <source>Delete record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="210"/>
        <source>new search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="229"/>
        <source>search !!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="248"/>
        <source>Order by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="267"/>
        <source>View alls records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="316"/>
        <source>DB Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="332"/>
        <source>Ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="425"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="446"/>
        <source>record n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="906"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="491"/>
        <source>record tot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="612"/>
        <source>Sito </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="619"/>
        <source>Sigla struttura</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="626"/>
        <source>N°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="659"/>
        <source>Aggiungi un valore...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="664"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="704"/>
        <source>Categoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="711"/>
        <source>Tipologia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="732"/>
        <source>Definizione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="775"/>
        <source>Dati descrittivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="799"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:13pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="810"/>
        <source>Descrizione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="838"/>
        <source>Interpretazione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="848"/>
        <source>Periodizzazione - Rapporti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="872"/>
        <source>Periodizzazione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="885"/>
        <source>Iniziale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="898"/>
        <source>Finale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="911"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="933"/>
        <source>Periodo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="940"/>
        <source>Fase </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="961"/>
        <source>Datazione estesa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="993"/>
        <source>Rapporti struttura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1283"/>
        <source>inserisci riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1039"/>
        <source>Tipo di rapporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1044"/>
        <source>Sito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1049"/>
        <source>Sigla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1054"/>
        <source>Numero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1065"/>
        <source>Elementi costruttivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1095"/>
        <source>Elementi strutturali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1131"/>
        <source>Tipologia elemnto</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1136"/>
        <source>Quantità</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1150"/>
        <source>Misurazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1186"/>
        <source>Tipo misura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1191"/>
        <source>Unita&apos; di misura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1196"/>
        <source>Valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1251"/>
        <source>Materiali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_Struttura_ui.ui" line="1265"/>
        <source>Materiali impiegati</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogUS</name>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="20"/>
        <source>pyArchInit Gestione Scavi - Scheda US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="60"/>
        <source>DBMS Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="67"/>
        <source>Reload DB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="76"/>
        <source>First rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="90"/>
        <source>Prev rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="104"/>
        <source>Next rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="118"/>
        <source>Last rec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="137"/>
        <source>New record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="156"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="178"/>
        <source>Delete record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="210"/>
        <source>new search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="229"/>
        <source>search !!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="248"/>
        <source>Order by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="267"/>
        <source>View alls records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="316"/>
        <source>DB Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="332"/>
        <source>Ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="425"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="446"/>
        <source>record n.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1064"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="491"/>
        <source>record tot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2217"/>
        <source>Inserisci un valore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1069"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="621"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="626"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="631"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="636"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="641"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="646"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="651"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="656"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="661"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="666"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="671"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="676"/>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="681"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="686"/>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="691"/>
        <source>17</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="696"/>
        <source>18</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="701"/>
        <source>19</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="706"/>
        <source>20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="738"/>
        <source>Sito </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="761"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1322"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="837"/>
        <source>Attivita&apos; di cantiere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="842"/>
        <source>Abbandono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="847"/>
        <source>Fognatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="852"/>
        <source>Fondazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="857"/>
        <source>Fossa da grano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="862"/>
        <source>Livellamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="867"/>
        <source>Muro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="872"/>
        <source>Pavimentazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="877"/>
        <source>Pavimentazione a mosaico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="882"/>
        <source>Palo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="890"/>
        <source>Definizione stratigrafica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="897"/>
        <source>Definizione Interpretata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="931"/>
        <source>Dati descrittivi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="943"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:13pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="954"/>
        <source>Descrizione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="970"/>
        <source>Interpretazione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="980"/>
        <source>Periodizzazione - Rapporti Stratigrafici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1004"/>
        <source>Periodizzazione </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1017"/>
        <source>Iniziale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1030"/>
        <source>Finale </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1043"/>
        <source>Attivita&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1056"/>
        <source>Struttura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1121"/>
        <source>Periodo </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1128"/>
        <source>Fase </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1169"/>
        <source>Meccanico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1174"/>
        <source>Stratigrafico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1182"/>
        <source>Metodo di scavo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1189"/>
        <source>Anno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1218"/>
        <source>Si</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1223"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1231"/>
        <source>Scavato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1253"/>
        <source>Rapporti stratigrafici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1648"/>
        <source>inserisci riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1660"/>
        <source>rimuovi riga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1317"/>
        <source>Tipo di rapporto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1333"/>
        <source>Dati Fisici - Dati Schedatore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1350"/>
        <source>Antropico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1355"/>
        <source>Naturale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1392"/>
        <source>Inclusi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1429"/>
        <source>                     Campioni                </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1442"/>
        <source>Formazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1458"/>
        <source>Marrone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1463"/>
        <source>Marrone chiaro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1468"/>
        <source>Marrone scuro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1562"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1478"/>
        <source>Giallo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1483"/>
        <source>Giallo scuro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1488"/>
        <source>Giallo chiaro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1516"/>
        <source>Colore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1532"/>
        <source>Argillosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1537"/>
        <source>Compatta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1542"/>
        <source>Friabile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1547"/>
        <source>Sabbiosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1575"/>
        <source>Consistenza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1591"/>
        <source>Insufficiente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1596"/>
        <source>Scarso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1601"/>
        <source>Buono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1606"/>
        <source>Discreto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1611"/>
        <source>Ottimo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1672"/>
        <source>Stato di conservazione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1704"/>
        <source>Data schedatura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1732"/>
        <source>Luca Mandolesi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1745"/>
        <source>Schedatore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1796"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1809"/>
        <source>Crea Codice Periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1822"/>
        <source>Esporta Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2080"/>
        <source>Show Selcted Features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1843"/>
        <source>Crea codice periodo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1859"/>
        <source>Ordine Stratigrafico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2230"/>
        <source>Export PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1880"/>
        <source>export Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1911"/>
        <source>Visualizzazione GIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1987"/>
        <source>Visualizza US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="1937"/>
        <source>Attivazione Preview pianta US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2043"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2001"/>
        <source>Preview pianta US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2033"/>
        <source>Pan tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2068"/>
        <source>Apri schede US selezionate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2083"/>
        <source>apri schede US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2100"/>
        <source>Esportazioni PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2115"/>
        <source>Singole schede US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2131"/>
        <source>Elenco US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2161"/>
        <source>Mostra immagini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2181"/>
        <source>Controlla rapporti stratigrafici</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/pyarchinit_US_ui.ui" line="2233"/>
        <source>Check, go!!!!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogView</name>
    <message>
        <location filename="imageViewer_ui.py" line="43"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog_Config</name>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="35"/>
        <source>Impostazioni del sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="55"/>
        <source>Parametri di connessione</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="61"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="90"/>
        <source>postgres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="95"/>
        <source>sqlite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="103"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="186"/>
        <source>&apos;&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="117"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="131"/>
        <source>DBname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="145"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="159"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="179"/>
        <source>Thumbnail path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="196"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="210"/>
        <source>Installazione layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="225"/>
        <source>Installa il database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="260"/>
        <source>Installa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="239"/>
        <source>Installa il db geografico su Postgres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/Ui_pyarchinitConfig.ui" line="253"/>
        <source>Installa il db geografico su sqlite</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog_Individui</name>
</context>
<context>
    <name>Dialog_tafonomia</name>
</context>
<context>
    <name>sortPanel</name>
    <message>
        <location filename="modules/gui/sort_panel_ui.ui" line="212"/>
        <source>Ordina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/sort_panel_ui.ui" line="28"/>
        <source>Criteri di ordinamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/sort_panel_ui.ui" line="126"/>
        <source>Ascendente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="modules/gui/sort_panel_ui.ui" line="136"/>
        <source>Discendente</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
