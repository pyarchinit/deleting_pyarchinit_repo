#!/usr/bin/env python
# -*- coding: utf-8 -*- 
"""
untitled.py

Created by pyarchinit on 2008-03-30.
Copyright (c) 2008 __MyCompanyName__. All rights reserved.
"""

import os


def main():
	i = 0

	pyarchinit_path = os.path.dirname(__file__)

	if i == 0:
		str_cmd_0 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_US_ui.ui	 -o ',\
		pyarchinit_path, '/pyarchinit_US_ui.py')
		print str_cmd_0
		os.system(str_cmd_0)

	elif i == 1:
		str_cmd_1 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/sort_panel_ui.ui  -o ',\
		pyarchinit_path, '/sort_panel_ui.py')
		os.system(str_cmd_1)
		
	elif i == 2:
		str_cmd_2 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_alert_message_ui.ui	-o ',\
		pyarchinit_path, '/pyarchinit_alert_message_ui.py')
		os.system(str_cmd_2)
		
	elif i == 3:
		str_cmd_3 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/Ui_pyarchinitConfig.ui	-o ',\
		pyarchinit_path, '/Ui_pyarchinitConfig.py')
		os.system(str_cmd_3)
		
	elif i == 4:
		str_cmd_4 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_Site_ui.ui  -o ',\
		pyarchinit_path, '/pyarchinit_Site_ui.py')
		os.system(str_cmd_4)
		
	elif i == 5:
		str_cmd_5 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_Periodo_fase_ui.ui  -o ',\
		pyarchinit_path, '/pyarchinit_Periodo_fase_ui.py')
		os.system(str_cmd_5)		
		
	elif i == 6:
		str_cmd_6 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_inventario_reperti_ui.ui  -o ',\
		pyarchinit_path, '/pyarchinit_inventario_reperti_ui.py')
		os.system(str_cmd_6)

	elif i == 7:
		str_cmd_7 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/Ui_UpdValues.ui  -o ',\
		pyarchinit_path, '/Ui_UpdValues.py')
		os.system(str_cmd_7)

	elif i == 8:
		str_cmd_7 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/info.ui  -o ',\
		pyarchinit_path, '/info.py')
		os.system(str_cmd_7)

	elif i == 9:
		str_cmd_7 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_gis_time_controller.ui  -o ',\
		pyarchinit_path, '/pyarchinit_gis_time_controller.py')
		os.system(str_cmd_7)

	elif i == 10:
		str_cmd_8 = ('%s%s%s%s%s') % ('pyuic4 ', pyarchinit_path, '/pyarchinit_struttura_ui.ui  -o ',\
		pyarchinit_path, '/pyarchinit_Struttura_ui.py')
		os.system(str_cmd_8)

if __name__ == '__main__':
	main()
