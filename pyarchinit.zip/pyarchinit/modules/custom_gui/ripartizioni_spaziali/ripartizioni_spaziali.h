#ifndef RIPARTIZIONI_SPAZIALI_H
#define RIPARTIZIONI_SPAZIALI_H

#include <QWidget>

class ripartizioni_spaziali : public QWidget
{
    Q_OBJECT
    
public:
    ripartizioni_spaziali(QWidget *parent = 0);
};

#endif
