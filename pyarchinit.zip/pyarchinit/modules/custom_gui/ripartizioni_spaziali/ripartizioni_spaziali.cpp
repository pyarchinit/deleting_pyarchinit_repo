#include "ripartizioni_spaziali.h"

ripartizioni_spaziali::ripartizioni_spaziali(QWidget *parent) :
    QWidget(parent)
{
}
